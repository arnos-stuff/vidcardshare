# Make mini video-sharing card-like websites

TODO: Add link